// ============================================================
// ANIMATIONS — All GSAP timelines and ScrollTrigger instances
// FIXED: hero-text opacity placement, mobile-safe gallery entrance
// ============================================================
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

export function initAnimations(lenis) {

  // ── Character-level text split ──
  function splitChars(el) {
    const text = el.textContent;
    el.innerHTML = '';
    text.split('').forEach(char => {
      const span = document.createElement('span');
      span.className = 'char';
      span.style.display = 'inline-block';
      span.textContent = char === ' ' ? '\u00A0' : char;
      el.appendChild(span);
    });
    return el.querySelectorAll('.char');
  }

  // Split hero headline lines
  document.querySelectorAll('[data-split-chars] .hl-line:not(.mood-line)').forEach(line => splitChars(line));
  // Split non-hero section headings
  document.querySelectorAll('[data-split-chars]:not(.hero-headline)').forEach(h => {
    if (!h.querySelector('.char') && !h.querySelector('.hl-line')) splitChars(h);
  });

  // ── Entrance sequence ──
  const entranceTl = gsap.timeline({ delay: 0.15 });

  entranceTl
    .fromTo('#nav-logo',
      { opacity: 0, y: -10 },
      { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' }, 0.1)
    .fromTo('.nav-links',
      { opacity: 0, y: -8 },
      { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' }, 0.15)
    .fromTo('#reserve-btn',
      { opacity: 0, y: -8 },
      { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' }, 0.2);

  // Atmosphere card
  entranceTl.fromTo('#atmo-card',
    { opacity: 0, x: -40, rotateY: 12 },
    { opacity: 1, x: 0, rotateY: 0, duration: 1.1, ease: 'expo.out' }, 0.55);

  // FIX: Set hero-text visible JUST before chars animate
  entranceTl.set('.hero-text', { opacity: 1 }, 0.64);

  // Hero eyebrow
  entranceTl.fromTo('.hero-text .eyebrow',
    { opacity: 0, y: 10 },
    { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out' }, 0.6);

  // Character-level headline animation
  const heroChars = document.querySelectorAll('#hero-text .hl-line:not(.mood-line) .char');
  if (heroChars.length > 0) {
    entranceTl.fromTo(heroChars,
      { opacity: 0, y: 30, rotateX: -40 },
      { opacity: 1, y: 0, rotateX: 0, duration: 0.7, stagger: 0.022, ease: 'expo.out' }, 0.65);
  }

  entranceTl
    .fromTo('.hero-mood',
      { opacity: 0, y: 8 },
      { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' }, 1.0)
    .fromTo('.hero-cta-strip',
      { opacity: 0, y: 10, scale: 0.97 },
      { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: 'back.out(1.5)' }, 1.1);

  // Signature SVG draw
  entranceTl
    .fromTo('#sig-wrap', { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.4 }, 1.2)
    .to('.sp1', { strokeDashoffset: 0, duration: 1.6, ease: 'power2.inOut' }, 1.2)
    .to('.sp2', { strokeDashoffset: 0, duration: 1.0, ease: 'power2.inOut' }, 1.8)
    .to('.sp3', { strokeDashoffset: 0, duration: 0.7, ease: 'power2.inOut' }, 2.0);

  // Scroll indicator
  entranceTl.fromTo('#scroll-indicator',
    { opacity: 0 },
    { opacity: 1, duration: 0.6, ease: 'power2.out' }, 2.8);

  // ── Liquid glass card hover (desktop) + touch ──
  const card = document.getElementById('atmo-card');
  if (card) {
    card.addEventListener('mouseenter', () =>
      gsap.to(card, { scale: 1.035, y: -6, duration: 0.55, ease: 'power3.out', overwrite: 'auto' }));
    card.addEventListener('mouseleave', () =>
      gsap.to(card, { scale: 1, y: 0, duration: 0.55, ease: 'power3.out', overwrite: 'auto' }));
    card.addEventListener('touchstart', () =>
      gsap.to(card, { scale: 1.02, duration: 0.2, ease: 'power2.out' }), { passive: true });
    card.addEventListener('touchend', () =>
      gsap.to(card, { scale: 1, duration: 0.5, ease: 'elastic.out(1, 0.5)' }));
  }

  // ── Atmosphere section ──
  ScrollTrigger.create({
    trigger: '#atmosphere-section', start: 'top 75%', once: true,
    onEnter: () => {
      const chars = document.querySelectorAll('#atmosphere-section [data-split-chars] .char');
      gsap.fromTo(chars,
        { opacity: 0, y: 25, rotateX: -30 },
        { opacity: 1, y: 0, rotateX: 0, stagger: 0.025, duration: 0.65, ease: 'expo.out', delay: 0.1 });
      gsap.fromTo('.space-card',
        { opacity: 0, y: 40, scale: 0.96 },
        { opacity: 1, y: 0, scale: 1, stagger: 0.12, duration: 0.9, ease: 'expo.out', delay: 0.3 });
    }
  });

  // Gyroscope tilt on space cards — mobile only
  if (window.DeviceOrientationEvent && 'ontouchstart' in window) {
    window.addEventListener('deviceorientation', (e) => {
      if (e.beta == null || e.gamma == null) return;
      const cards = document.querySelectorAll('.space-card');
      const tiltX = Math.min(Math.max(e.beta - 45, -15), 15);
      const tiltY = Math.min(Math.max(e.gamma, -15), 15);
      cards.forEach(c => gsap.to(c, {
        rotateX: tiltX * 0.3, rotateY: tiltY * 0.3,
        duration: 0.8, ease: 'power2.out', overwrite: 'auto',
      }));
    });
  }

  // ── Story section ──
  ScrollTrigger.create({
    trigger: '#story-section', start: 'top 72%', once: true,
    onEnter: () => {
      gsap.fromTo('.story-text',
        { opacity: 0, x: -30 },
        { opacity: 1, x: 0, duration: 1.0, ease: 'expo.out' });
      gsap.fromTo('.story-photo-wrap',
        { opacity: 0, x: 30, scale: 0.97 },
        { opacity: 1, x: 0, scale: 1, duration: 1.0, ease: 'expo.out', delay: 0.15 });
      gsap.fromTo('.story-photo-tag',
        { opacity: 0, y: 20, scale: 0.9 },
        { opacity: 1, y: 0, scale: 1, duration: 0.7, ease: 'back.out(1.5)', delay: 0.5 });
    }
  });

  // ── Gallery — parallax + entrance ──
  document.querySelectorAll('.gallery-item').forEach((item, i) => {
    const speed = parseFloat(item.dataset.parallaxSpeed || 0.15);

    // Parallax scroll per item
    gsap.to(item.querySelector('img'), {
      yPercent: -speed * 100,
      ease: 'none',
      scrollTrigger: { trigger: item, start: 'top bottom', end: 'bottom top', scrub: true },
    });

    // FIX: Mobile-safe entrance — replaced clipPath (Safari bug) with x + blur
    ScrollTrigger.create({
      trigger: item, start: 'top 88%', once: true,
      onEnter: () => gsap.fromTo(item,
        { opacity: 0, x: 40, filter: 'blur(6px)' },
        { opacity: 1, x: 0, filter: 'blur(0px)', duration: 0.9, ease: 'expo.out', delay: i * 0.08 }),
    });

    // Hover depth zoom — desktop only
    item.addEventListener('mouseenter', () =>
      gsap.to(item.querySelector('img'), { scale: 1.05, duration: 0.6, ease: 'power2.out' }));
    item.addEventListener('mouseleave', () =>
      gsap.to(item.querySelector('img'), { scale: 1, duration: 0.6, ease: 'power2.out' }));
  });

  // ── Visit section ──
  ScrollTrigger.create({
    trigger: '#visit-section', start: 'top 75%', once: true,
    onEnter: () => {
      gsap.fromTo('.visit-info > *',
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, stagger: 0.08, duration: 0.7, ease: 'expo.out' });
      gsap.fromTo('.visit-map-wrap',
        { opacity: 0, scale: 0.96 },
        { opacity: 1, scale: 1, duration: 0.9, ease: 'expo.out', delay: 0.2 });
      gsap.fromTo('.facility-tag',
        { opacity: 0, scale: 0.88, y: 10 },
        { opacity: 1, scale: 1, y: 0, stagger: 0.06, duration: 0.5, ease: 'back.out(1.5)', delay: 0.4 });
      gsap.fromTo('.zomato-badge',
        { opacity: 0, scale: 0.8, y: 15 },
        { opacity: 1, scale: 1, y: 0, duration: 0.7, ease: 'elastic.out(1, 0.5)', delay: 0.7 });
    }
  });

  // ── Footer ──
  ScrollTrigger.create({
    trigger: '#site-footer', start: 'top 80%', once: true,
    onEnter: () => {
      gsap.fromTo('.footer-brand, .footer-links, .footer-hours',
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, stagger: 0.12, duration: 0.8, ease: 'expo.out' });
      gsap.fromTo('.social-link',
        { opacity: 0, scale: 0.9 },
        { opacity: 1, scale: 1, stagger: 0.08, duration: 0.5, ease: 'back.out(1.5)', delay: 0.4 });
    }
  });

  // ── Background color transitions on scroll ──
  ScrollTrigger.create({
    trigger: '#atmosphere-section', start: 'top 60%', end: 'bottom 40%',
    onEnter:     () => gsap.to('body', { backgroundColor: '#EDE4D0', duration: 0.8, ease: 'power2.out' }),
    onLeaveBack: () => gsap.to('body', { backgroundColor: '#F5EDDE', duration: 0.8, ease: 'power2.out' }),
  });
  ScrollTrigger.create({
    trigger: '#story-section', start: 'top 60%', end: 'bottom 40%',
    onEnter:     () => gsap.to('body', { backgroundColor: '#F5EDDE', duration: 0.8, ease: 'power2.out' }),
    onLeaveBack: () => gsap.to('body', { backgroundColor: '#EDE4D0', duration: 0.8, ease: 'power2.out' }),
  });
  ScrollTrigger.create({
    trigger: '#gallery-section', start: 'top 60%', end: 'bottom 40%',
    onEnter:     () => gsap.to('body', { backgroundColor: '#E0D5BE', duration: 0.8, ease: 'power2.out' }),
    onLeaveBack: () => gsap.to('body', { backgroundColor: '#F5EDDE', duration: 0.8, ease: 'power2.out' }),
  });
}
