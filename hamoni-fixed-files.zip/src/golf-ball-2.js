// ============================================================
// GOLF BALL 2 + TEE — zig-zag scroll journey → lands on tee
// FIXED: render skip bug, tee rotation conflict, dispose import
// ============================================================
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
// FIX: Import dispose function to free Ball 1 renderer when Ball 2 appears
import { disposeGolfBall1 } from './golf-ball.js';

const GOLF_BALL_URL = 'https://raw.githubusercontent.com/loveparihar8900-cyber/Golf-ball/main/golf_ball%20(1).glb';
const GOLF_TEE_URL  = 'https://raw.githubusercontent.com/loveparihar8900-cyber/3d-golf-ball-tee/main/golf_tee.glb';

const IS_MOBILE = window.innerWidth <= 768;
const WAYPOINTS = [
  { section: 'atmosphere', x: IS_MOBILE ?  1.2 :  2.0, y:  0.4, z: 0, scale: 0.85, zIndex: 3  },
  { section: 'story',      x: IS_MOBILE ? -1.2 : -2.0, y:  0.0, z: 0, scale: 0.85, zIndex: 3  },
  { section: 'gallery',    x: IS_MOBILE ?  1.0 :  1.8, y: -0.3, z: 0, scale: 0.85, zIndex: 15 },
  { section: 'visit',      x: IS_MOBILE ? -1.0 : -1.6, y:  0.2, z: 0, scale: 0.85, zIndex: 3  },
  { section: 'footer',     x: 0,                        y: -0.8, z: 0, scale: 0.75, zIndex: 8  },
];

const TEE_POSITION    = { x: 0, y: -1.6, z: 0 };
const TEE_BALL_REST_Y = -0.85;

let scene2, camera2, renderer2, ball2, tee;
let ball2Loaded = false, teeLoaded = false;
let ball2BaseScale = 1, teeBaseScale = 1;
let hasLanded = false;
// FIX: Flag to stop tee y-rotation after landing (prevents wobble conflict)
let teeIdleRotate = true;

const autoVel2 = { x: 0.001, y: 0.0025 };

export async function initGolfBall2() {
  const canvas2 = document.createElement('canvas');
  canvas2.id = 'golf-ball-2-canvas';
  canvas2.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    width: 100vw; height: 100vh;
    z-index: 6;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.5s ease;
  `;
  document.body.appendChild(canvas2);

  renderer2 = new THREE.WebGLRenderer({
    canvas: canvas2,
    alpha: true,
    antialias: window.devicePixelRatio < 2,
    powerPreference: 'high-performance',
  });
  renderer2.setSize(window.innerWidth, window.innerHeight);
  renderer2.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer2.toneMapping = THREE.ACESFilmicToneMapping;
  renderer2.toneMappingExposure = 0.72;
  renderer2.outputColorSpace = THREE.SRGBColorSpace;

  scene2 = new THREE.Scene();
  camera2 = new THREE.PerspectiveCamera(32, window.innerWidth / window.innerHeight, 0.1, 200);
  camera2.position.set(0, 0, 5.5);

  const pmrem = new THREE.PMREMGenerator(renderer2);
  pmrem.compileEquirectangularShader();
  scene2.environment = pmrem.fromScene(new RoomEnvironment(renderer2), 0.04).texture;

  scene2.add(new THREE.AmbientLight(0xfff0dd, 0.55));
  const keyLight = new THREE.DirectionalLight(0xffeedd, 1.6);
  keyLight.position.set(-2, 4, 5);
  scene2.add(keyLight);
  const fillLight = new THREE.DirectionalLight(0xf5e8d0, 0.35);
  fillLight.position.set(4, 1, -2);
  scene2.add(fillLight);
  scene2.add(new THREE.HemisphereLight(0xfff0dd, 0xcfc0ae, 0.4));

  await Promise.all([loadBall2(), loadTee()]);
  setupZigZagScroll();
  animateBall2();

  window.addEventListener('resize', () => {
    camera2.aspect = window.innerWidth / window.innerHeight;
    camera2.updateProjectionMatrix();
    renderer2.setSize(window.innerWidth, window.innerHeight);
  });
}

// ── Load Ball 2 GLB ──
async function loadBall2() {
  return new Promise((resolve) => {
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.6/');
    const loader = new GLTFLoader();
    loader.setDRACOLoader(dracoLoader);
    loader.load(
      GOLF_BALL_URL,
      (gltf) => {
        ball2 = gltf.scene;
        const box = new THREE.Box3().setFromObject(ball2);
        ball2.position.sub(box.getCenter(new THREE.Vector3()));
        const size = box.getSize(new THREE.Vector3());
        ball2BaseScale = 2.4 / Math.max(size.x, size.y, size.z);
        ball2.scale.setScalar(ball2BaseScale * WAYPOINTS[0].scale);
        ball2.position.set(WAYPOINTS[0].x, WAYPOINTS[0].y - 1.5, WAYPOINTS[0].z);
        ball2.traverse((child) => {
          if (child.isMesh && child.material) {
            const mats = Array.isArray(child.material) ? child.material : [child.material];
            mats.forEach(mat => {
              mat.envMapIntensity = 0.18;
              if (mat.roughness !== undefined) mat.roughness = Math.min(1.0, Math.max(0.78, (mat.roughness ?? 0.5) * 1.45));
              if (mat.metalness !== undefined) mat.metalness = 0;
              if (mat.color) mat.color.multiplyScalar(0.72);
              mat.needsUpdate = true;
            });
          }
        });
        scene2.add(ball2);
        ball2Loaded = true;
        resolve();
      },
      undefined,
      (err) => { console.warn('Ball2 load error:', err); resolve(); }
    );
  });
}

// ── Load Tee GLB — original colors preserved ──
async function loadTee() {
  return new Promise((resolve) => {
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.6/');
    const loader = new GLTFLoader();
    loader.setDRACOLoader(dracoLoader);
    loader.load(
      GOLF_TEE_URL,
      (gltf) => {
        tee = gltf.scene;
        const box = new THREE.Box3().setFromObject(tee);
        tee.position.sub(box.getCenter(new THREE.Vector3()));
        const size = box.getSize(new THREE.Vector3());
        teeBaseScale = 1.8 / Math.max(size.x, size.y, size.z);
        tee.scale.setScalar(teeBaseScale);
        tee.position.set(TEE_POSITION.x, TEE_POSITION.y, TEE_POSITION.z);
        // NO color override — preserve original GLB tee colors
        tee.traverse((child) => {
          if (child.isMesh && child.material) {
            const mats = Array.isArray(child.material) ? child.material : [child.material];
            mats.forEach(mat => { mat.envMapIntensity = 0.3; mat.needsUpdate = true; });
          }
        });
        tee.visible = false;
        scene2.add(tee);
        teeLoaded = true;
        resolve();
      },
      undefined,
      (err) => { console.warn('Tee load error:', err); resolve(); }
    );
  });
}

// ── Ball 2 Entry Animation ──
function ball2Enter() {
  if (!ball2Loaded) return;
  // FIX: Dispose Ball 1 to free GPU memory — only one renderer at a time
  disposeGolfBall1();

  const canvas2 = document.getElementById('golf-ball-2-canvas');
  gsap.to(canvas2, { opacity: 1, duration: 0.5, ease: 'power2.out' });

  ball2.scale.setScalar(0);
  ball2.position.set(WAYPOINTS[0].x, WAYPOINTS[0].y - 2, 0);

  gsap.to(ball2.scale, {
    x: ball2BaseScale * WAYPOINTS[0].scale,
    y: ball2BaseScale * WAYPOINTS[0].scale,
    z: ball2BaseScale * WAYPOINTS[0].scale,
    duration: 0.9, ease: 'back.out(1.7)',
  });
  gsap.to(ball2.position, { y: WAYPOINTS[0].y, duration: 0.9, ease: 'expo.out' });
}

// ── Zig-Zag Scroll Path ──
function setupZigZagScroll() {
  // Entry trigger
  ScrollTrigger.create({
    trigger: '#atmosphere-section', start: 'top 60%', once: true,
    onEnter: ball2Enter,
  });

  // Atmosphere → Story (right → left)
  ScrollTrigger.create({
    trigger: '#story-section', start: 'top bottom', end: 'top top', scrub: 1.5,
    onUpdate: (self) => {
      if (!ball2Loaded) return;
      const p = self.progress;
      ball2.position.x = gsap.utils.interpolate(WAYPOINTS[0].x, WAYPOINTS[1].x, p);
      ball2.position.y = gsap.utils.interpolate(WAYPOINTS[0].y, WAYPOINTS[1].y, p) + Math.sin(p * Math.PI) * 0.15;
      updateBall2ZIndex(WAYPOINTS[1].zIndex);
    },
  });

  // Story → Gallery (left → right)
  ScrollTrigger.create({
    trigger: '#gallery-section', start: 'top bottom', end: 'top top', scrub: 1.5,
    onUpdate: (self) => {
      if (!ball2Loaded) return;
      const p = self.progress;
      ball2.position.x = gsap.utils.interpolate(WAYPOINTS[1].x, WAYPOINTS[2].x, p);
      ball2.position.y = gsap.utils.interpolate(WAYPOINTS[1].y, WAYPOINTS[2].y, p) + Math.sin(p * Math.PI) * 0.12;
      updateBall2ZIndex(WAYPOINTS[2].zIndex);
    },
  });

  // Gallery → Visit (right → left)
  ScrollTrigger.create({
    trigger: '#visit-section', start: 'top bottom', end: 'top top', scrub: 1.5,
    onUpdate: (self) => {
      if (!ball2Loaded) return;
      const p = self.progress;
      ball2.position.x = gsap.utils.interpolate(WAYPOINTS[2].x, WAYPOINTS[3].x, p);
      ball2.position.y = gsap.utils.interpolate(WAYPOINTS[2].y, WAYPOINTS[3].y, p) + Math.sin(p * Math.PI) * 0.1;
      updateBall2ZIndex(WAYPOINTS[3].zIndex);
    },
  });

  // Visit → Footer — tee appears, ball descends onto tee
  ScrollTrigger.create({
    trigger: '#site-footer', start: 'top bottom', end: 'top 30%', scrub: 1.5,
    onEnter: () => {
      if (teeLoaded && tee) {
        tee.visible = true;
        tee.scale.setScalar(0);
        gsap.to(tee.scale, {
          x: teeBaseScale, y: teeBaseScale, z: teeBaseScale,
          duration: 0.8, ease: 'back.out(1.4)',
        });
      }
    },
    onUpdate: (self) => {
      if (!ball2Loaded) return;
      const p = self.progress;
      ball2.position.x = gsap.utils.interpolate(WAYPOINTS[3].x, WAYPOINTS[4].x, p);
      const startY = WAYPOINTS[3].y;
      const endY   = TEE_BALL_REST_Y + 0.8;
      ball2.position.y = gsap.utils.interpolate(startY, endY, gsap.parseEase('power2.in')(p));
      ball2.scale.setScalar(
        gsap.utils.interpolate(ball2BaseScale * WAYPOINTS[3].scale, ball2BaseScale * WAYPOINTS[4].scale, p)
      );
      updateBall2ZIndex(8);
      if (p >= 0.98 && !hasLanded) { hasLanded = true; triggerLanding(); }
    },
    onLeaveBack: () => { hasLanded = false; },
  });
}

// ── Landing: bounce + tee wobble ──
function triggerLanding() {
  if (!ball2 || !tee) return;
  document.getElementById('tee-stage')?.classList.add('ball-landed');

  const landingTl = gsap.timeline();
  // Drop onto tee
  landingTl.to(ball2.position, { y: TEE_BALL_REST_Y, duration: 0.25, ease: 'power3.in' });
  // Squish on impact
  landingTl.to(ball2.scale, { y: ball2BaseScale * WAYPOINTS[4].scale * 0.82, duration: 0.08, ease: 'power2.out' }, '-=0.02');
  // First bounce up
  landingTl.to(ball2.position, { y: TEE_BALL_REST_Y + 0.3, duration: 0.18, ease: 'power2.out' });
  landingTl.to(ball2.scale, { y: ball2BaseScale * WAYPOINTS[4].scale, duration: 0.15, ease: 'elastic.out(1, 0.5)' }, '<');
  // Second smaller bounce
  landingTl.to(ball2.position, { y: TEE_BALL_REST_Y + 0.08, duration: 0.12, ease: 'power2.in' });
  landingTl.to(ball2.position, { y: TEE_BALL_REST_Y, duration: 0.1, ease: 'power2.out' });
  // Final settle
  landingTl.to(ball2.position, { y: TEE_BALL_REST_Y, duration: 0.3, ease: 'power3.out' });

  // Tee wobble — fires at impact moment
  gsap.timeline({ delay: 0.22 })
    .to(tee.rotation, { z:  0.18, duration: 0.08, ease: 'power2.out'   })
    .to(tee.rotation, { z: -0.12, duration: 0.10, ease: 'power2.inOut' })
    .to(tee.rotation, { z:  0.07, duration: 0.08, ease: 'power2.inOut' })
    .to(tee.rotation, { z: -0.04, duration: 0.07, ease: 'power2.inOut' })
    .to(tee.rotation, { z:  0.0,  duration: 0.12, ease: 'elastic.out(1, 0.3)' });

  // After settle: idle float + stop tee y-rotation
  landingTl.call(() => {
    // FIX: Stop y-rotation so it doesn't fight wobble animation
    teeIdleRotate = false;
    autoVel2.y = 0.001;
    autoVel2.x = 0;
    // Gentle idle float on tee
    gsap.to(ball2.position, {
      y: TEE_BALL_REST_Y + 0.04,
      duration: 2.5,
      ease: 'sine.inOut',
      repeat: -1,
      yoyo: true,
    });
  });
}

function updateBall2ZIndex(zIndex) {
  const canvas2 = document.getElementById('golf-ball-2-canvas');
  if (canvas2) canvas2.style.zIndex = zIndex;
}

// ── Render Loop ──
function animateBall2() {
  requestAnimationFrame(animateBall2);

  // FIX: Only skip render before ball has ever loaded — not based on opacity
  // opacity check was preventing render after ball2Enter() faded canvas in
  if (!ball2Loaded && !teeLoaded) return;

  if (ball2) {
    ball2.rotation.x += autoVel2.x;
    ball2.rotation.y += autoVel2.y;
  }
  // FIX: Only rotate tee when not in wobble/settled state
  if (tee && teeIdleRotate) tee.rotation.y += 0.003;

  renderer2.render(scene2, camera2);
}
