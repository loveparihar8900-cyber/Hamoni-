// ============================================================
// GOLF BALL 1 — Three.js, hero only, drag + momentum
// FIXED: Added gallery + visit waypoints, touchmove on canvas
// ============================================================
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const GOLF_BALL_URL = 'https://raw.githubusercontent.com/loveparihar8900-cyber/Golf-ball/main/golf_ball%20(1).glb';
const IS_MOBILE = window.innerWidth <= 768;
const BALL_SCALE = IS_MOBILE ? 0.85 : 0.97;
const FOOTER_SCALE = IS_MOBILE ? 0.35 : 0.5;

// FIX: Added gallery + visit waypoints for smooth continuous journey
const SECTIONS = {
  hero:       { x: IS_MOBILE ?  0.3 :  0.5,  y: -0.3, z: 0,    scale: BALL_SCALE   },
  atmosphere: { x: IS_MOBILE ?  1.4 :  2.2,  y:  0.0, z: 0,    scale: BALL_SCALE   },
  story:      { x: IS_MOBILE ? -1.4 : -2.2,  y:  0.0, z: 0,    scale: BALL_SCALE   },
  gallery:    { x: IS_MOBILE ?  1.0 :  1.8,  y: -0.2, z: 0,    scale: BALL_SCALE   },
  visit:      { x: IS_MOBILE ? -0.8 : -1.5,  y:  0.0, z: 0,    scale: BALL_SCALE   },
  footer:     { x: IS_MOBILE ?  1.6 :  2.5,  y: -1.3, z: -2.0, scale: FOOTER_SCALE },
};

let scene, camera, renderer, ball;
let baseScale = 1, ballLoaded = false, isDragging = false, currentSection = 'hero';
let disposed = false;
const autoVel = { x: (Math.random() - 0.5) * 0.003, y: 0.003 + Math.random() * 0.002 };
const drag = { active: false, prevX: 0, prevY: 0, velX: 0, velY: 0 };
const DAMPING = 0.94;

export async function initGolfBall() {
  const canvas = document.getElementById('golf-ball-canvas');
  if (!canvas) return;

  renderer = new THREE.WebGLRenderer({
    canvas,
    alpha: true,
    antialias: window.devicePixelRatio < 2,
    powerPreference: 'high-performance',
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.72;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = false;

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(32, window.innerWidth / window.innerHeight, 0.1, 200);
  camera.position.set(0, 0, 5.5);

  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  scene.environment = pmrem.fromScene(new RoomEnvironment(renderer), 0.04).texture;

  scene.add(new THREE.AmbientLight(0xfff0dd, 0.55));
  const keyLight = new THREE.DirectionalLight(0xffeedd, 1.6);
  keyLight.position.set(-2, 4, 5);
  scene.add(keyLight);
  const fillLight = new THREE.DirectionalLight(0xf5e8d0, 0.35);
  fillLight.position.set(4, 1, -2);
  scene.add(fillLight);
  scene.add(new THREE.HemisphereLight(0xfff0dd, 0xcfc0ae, 0.4));

  await loadGolfBall();
  setupDrag(canvas);
  setupScrollBall();
  animate();

  window.addEventListener('resize', () => {
    if (disposed) return;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
}

async function loadGolfBall() {
  return new Promise((resolve) => {
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.6/');
    const loader = new GLTFLoader();
    loader.setDRACOLoader(dracoLoader);
    loader.load(
      GOLF_BALL_URL,
      (gltf) => {
        ball = gltf.scene;
        const box = new THREE.Box3().setFromObject(ball);
        ball.position.sub(box.getCenter(new THREE.Vector3()));
        const size = box.getSize(new THREE.Vector3());
        baseScale = 2.4 / Math.max(size.x, size.y, size.z);
        ball.scale.setScalar(baseScale * SECTIONS.hero.scale);
        ball.position.set(SECTIONS.hero.x, SECTIONS.hero.y, SECTIONS.hero.z);
        ball.traverse((child) => {
          if (child.isMesh && child.material) {
            const m = Array.isArray(child.material) ? child.material : [child.material];
            m.forEach(mat => {
              mat.envMapIntensity = 0.18;
              if (mat.roughness !== undefined) mat.roughness = Math.min(1.0, Math.max(0.78, (mat.roughness ?? 0.5) * 1.45));
              if (mat.metalness !== undefined) mat.metalness = 0;
              if (mat.color) mat.color.multiplyScalar(0.72);
              mat.needsUpdate = true;
            });
          }
        });
        scene.add(ball);
        ballLoaded = true;
        ballEntrance();
        resolve();
      },
      undefined,
      (error) => { console.error('Golf ball load error:', error); resolve(); }
    );
  });
}

function ballEntrance() {
  if (!ball) return;
  ball.scale.setScalar(baseScale * SECTIONS.hero.scale * 0.25);
  ball.position.y = SECTIONS.hero.y - 0.8;
  ball.rotation.y = Math.random() * Math.PI * 2;
  const tl = gsap.timeline({ delay: 0.5 });
  tl.to(ball.scale, {
    x: baseScale * SECTIONS.hero.scale,
    y: baseScale * SECTIONS.hero.scale,
    z: baseScale * SECTIONS.hero.scale,
    duration: 1.3, ease: 'expo.out',
  }, 0);
  tl.to(ball.position, { y: SECTIONS.hero.y, duration: 1.3, ease: 'expo.out' }, 0);
  tl.fromTo('#golf-ball-canvas', { opacity: 0 }, { opacity: 1, duration: 0.8, ease: 'power2.out' }, 0.2);
  tl.call(() => {
    enableDrag();
    document.getElementById('drag-hint')?.classList.add('visible');
  }, [], 1.4);
}

function enableDrag() { document.getElementById('golf-ball-canvas')?.classList.add('drag-enabled'); }
function disableDrag() { document.getElementById('golf-ball-canvas')?.classList.remove('drag-enabled'); }

function setupDrag(canvas) {
  function getPos(e) {
    return e.touches ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : { x: e.clientX, y: e.clientY };
  }
  function onDragStart(e) {
    if (currentSection !== 'hero') return;
    drag.active = true; isDragging = true;
    const pos = getPos(e);
    drag.prevX = pos.x; drag.prevY = pos.y;
    drag.velX = 0; drag.velY = 0;
    canvas.classList.add('dragging');
  }
  function onDragMove(e) {
    if (!drag.active) return;
    e.preventDefault();
    const pos = getPos(e);
    drag.velX = (pos.x - drag.prevX) * 0.006;
    drag.velY = (pos.y - drag.prevY) * 0.006;
    if (ball) { ball.rotation.y += drag.velX; ball.rotation.x += drag.velY; }
    drag.prevX = pos.x; drag.prevY = pos.y;
  }
  function onDragEnd() {
    if (!drag.active) return;
    drag.active = false; isDragging = false;
    canvas.classList.remove('dragging');
    const speed = Math.sqrt(drag.velX ** 2 + drag.velY ** 2);
    if (speed > 0.001) { autoVel.y = drag.velX * 0.7; autoVel.x = drag.velY * 0.7; }
  }
  canvas.addEventListener('mousedown', onDragStart);
  window.addEventListener('mousemove', onDragMove);
  window.addEventListener('mouseup', onDragEnd);
  canvas.addEventListener('touchstart', onDragStart, { passive: true });
  // FIX: touchmove on canvas not window — better perf
  canvas.addEventListener('touchmove', onDragMove, { passive: false });
  window.addEventListener('touchend', onDragEnd);
}

function setupScrollBall() {
  // Hero → Atmosphere
  ScrollTrigger.create({
    trigger: '#atmosphere-section', start: 'top bottom', end: 'top top', scrub: 2,
    onUpdate: (self) => {
      if (!ball) return;
      const p = self.progress;
      ball.position.x = gsap.utils.interpolate(SECTIONS.hero.x, SECTIONS.atmosphere.x, p);
      ball.position.y = gsap.utils.interpolate(SECTIONS.hero.y, SECTIONS.atmosphere.y, p);
      ball.position.z = gsap.utils.interpolate(SECTIONS.hero.z, SECTIONS.atmosphere.z, p);
      ball.scale.setScalar(gsap.utils.interpolate(baseScale * SECTIONS.hero.scale, baseScale * SECTIONS.atmosphere.scale, p));
    },
    onEnter: () => { currentSection = 'atmosphere'; disableDrag(); },
    onLeaveBack: () => { currentSection = 'hero'; enableDrag(); },
  });

  // Atmosphere → Story
  ScrollTrigger.create({
    trigger: '#story-section', start: 'top bottom', end: 'top top', scrub: 2,
    onUpdate: (self) => {
      if (!ball) return;
      const p = self.progress;
      ball.position.x = gsap.utils.interpolate(SECTIONS.atmosphere.x, SECTIONS.story.x, p);
      ball.position.y = gsap.utils.interpolate(SECTIONS.atmosphere.y, SECTIONS.story.y, p);
      ball.position.z = gsap.utils.interpolate(SECTIONS.atmosphere.z, SECTIONS.story.z, p);
      ball.scale.setScalar(gsap.utils.interpolate(baseScale * SECTIONS.atmosphere.scale, baseScale * SECTIONS.story.scale, p));
    },
    onEnter: () => { currentSection = 'story'; },
    onLeaveBack: () => { currentSection = 'atmosphere'; },
  });

  // FIX: Story → Gallery (was missing)
  ScrollTrigger.create({
    trigger: '#gallery-section', start: 'top bottom', end: 'top top', scrub: 2,
    onUpdate: (self) => {
      if (!ball) return;
      const p = self.progress;
      ball.position.x = gsap.utils.interpolate(SECTIONS.story.x, SECTIONS.gallery.x, p);
      ball.position.y = gsap.utils.interpolate(SECTIONS.story.y, SECTIONS.gallery.y, p);
      ball.position.z = gsap.utils.interpolate(SECTIONS.story.z, SECTIONS.gallery.z, p);
      ball.scale.setScalar(gsap.utils.interpolate(baseScale * SECTIONS.story.scale, baseScale * SECTIONS.gallery.scale, p));
    },
    onEnter: () => { currentSection = 'gallery'; },
    onLeaveBack: () => { currentSection = 'story'; },
  });

  // FIX: Gallery → Visit (was missing)
  ScrollTrigger.create({
    trigger: '#visit-section', start: 'top bottom', end: 'top top', scrub: 2,
    onUpdate: (self) => {
      if (!ball) return;
      const p = self.progress;
      ball.position.x = gsap.utils.interpolate(SECTIONS.gallery.x, SECTIONS.visit.x, p);
      ball.position.y = gsap.utils.interpolate(SECTIONS.gallery.y, SECTIONS.visit.y, p);
      ball.position.z = gsap.utils.interpolate(SECTIONS.gallery.z, SECTIONS.visit.z, p);
      ball.scale.setScalar(gsap.utils.interpolate(baseScale * SECTIONS.gallery.scale, baseScale * SECTIONS.visit.scale, p));
    },
    onEnter: () => { currentSection = 'visit'; },
    onLeaveBack: () => { currentSection = 'gallery'; },
  });

  // FIX: Visit → Footer (was story → footer)
  ScrollTrigger.create({
    trigger: '#site-footer', start: 'top bottom', end: 'top top', scrub: 2,
    onUpdate: (self) => {
      if (!ball || disposed) return;
      const p = self.progress;
      ball.position.x = gsap.utils.interpolate(SECTIONS.visit.x, SECTIONS.footer.x, p);
      ball.position.y = gsap.utils.interpolate(SECTIONS.visit.y, SECTIONS.footer.y, p);
      ball.position.z = gsap.utils.interpolate(SECTIONS.visit.z, SECTIONS.footer.z, p);
      ball.scale.setScalar(gsap.utils.interpolate(baseScale * SECTIONS.visit.scale, baseScale * SECTIONS.footer.scale, p));
      const opacity = p > 0.85 ? gsap.utils.mapRange(0.85, 1, 1, 0, p) : 1;
      if (renderer) renderer.domElement.style.opacity = opacity;
    },
    onEnter: () => { currentSection = 'footer'; },
    onLeaveBack: () => { currentSection = 'visit'; },
  });
}

function animate() {
  if (disposed) return;
  requestAnimationFrame(animate);
  if (ball && !isDragging) {
    autoVel.x *= DAMPING;
    autoVel.y *= DAMPING;
    const baseY = 0.003;
    if (Math.abs(autoVel.y) < baseY) autoVel.y = baseY;
    ball.rotation.x += autoVel.x;
    ball.rotation.y += autoVel.y;
  }
  if (renderer) renderer.render(scene, camera);
}

export function updateBallSection(section) { currentSection = section; }

export function disposeGolfBall1() {
  if (disposed) return;
  disposed = true;
  const canvas1 = document.getElementById('golf-ball-canvas');
  if (canvas1) {
    gsap.to(canvas1, {
      opacity: 0, duration: 0.5,
      onComplete: () => { if (renderer) renderer.dispose(); },
    });
  }
}
